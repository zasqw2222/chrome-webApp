// $(function(){
// 	var pi = $('#pi');
// 	alert(pi)
// })

// var pi = document.getElementById('pi');
// alert(pi.innerHTML)


function getround(){
	return {}
}